package com.capgemini.pizzaorder.service;

public interface IPizzaOrderService {

}
